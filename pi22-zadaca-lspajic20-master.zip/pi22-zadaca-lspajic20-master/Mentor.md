Povratne informacije mentora.
