﻿namespace DBLayer
{


    partial class lspajic20_DBDataSet
    {
    }
}
