﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentProcurementManager.Models
{
    public class Financiranje
    {
        public int idfinanciranje { get; set; } 
        public string nazivfinanc { get; set; }
    }
}
