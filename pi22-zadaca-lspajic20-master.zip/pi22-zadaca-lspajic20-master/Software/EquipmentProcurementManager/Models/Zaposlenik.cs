﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquipmentProcurementManager.Models
{
    public class Zaposlenik
    {
        public int Id { get; set; }
        public string korisnickoime { get; set; }  
        public string lozinka { get; set; } 


    }
}
