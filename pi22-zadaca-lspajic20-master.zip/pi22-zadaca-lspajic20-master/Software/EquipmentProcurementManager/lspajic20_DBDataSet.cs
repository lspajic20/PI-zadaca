﻿namespace EquipmentProcurementManager
{
}

namespace EquipmentProcurementManager
{
}

namespace EquipmentProcurementManager
{
}

namespace EquipmentProcurementManager
{
}
namespace EquipmentProcurementManager
{


    public partial class lspajic20_DBDataSet
    {
    }
}
namespace EquipmentProcurementManager {
    
    
    public partial class lspajic20_DBDataSet {
    }
}
